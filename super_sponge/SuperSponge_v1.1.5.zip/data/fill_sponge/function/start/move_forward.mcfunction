scoreboard players remove @s fillsponge 1
execute if block ~ ~ ~ end_stone run function fill_sponge:start/start_process
execute unless block ~ ~ ~ end_stone if score @s fillsponge matches 1.. positioned ^ ^ ^0.01 run function fill_sponge:start/move_forward