summon marker ~ ~ ~ {Duration:100000,Tags:["start_process"]}
setblock ~ ~ ~ end_stone

execute as @e[type=marker,tag=start_process,distance=..1] run function fill_sponge:handle_one