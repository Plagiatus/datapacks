advancement revoke @s only fill_sponge:place_sponge

scoreboard players set @s fillsponge 500
execute at @s anchored eyes positioned ^ ^ ^ anchored feet run function fill_sponge:start/move_forward
scoreboard players reset @s fillsponge
