setblock ~ ~ ~ air
kill @s