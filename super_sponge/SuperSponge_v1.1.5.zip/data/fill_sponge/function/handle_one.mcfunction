execute positioned ~1 ~ ~ if block ~ ~ ~ #fill_sponge:replace run summon marker ~ ~ ~ {Duration:100000,Tags:["filling_sponge","set_block"]}
execute positioned ~-1 ~ ~ if block ~ ~ ~ #fill_sponge:replace run summon marker ~ ~ ~ {Duration:100000,Tags:["filling_sponge","set_block"]}
execute positioned ~ ~1 ~ if block ~ ~ ~ #fill_sponge:replace run summon marker ~ ~ ~ {Duration:100000,Tags:["filling_sponge","set_block"]}
execute positioned ~ ~-1 ~ if block ~ ~ ~ #fill_sponge:replace run summon marker ~ ~ ~ {Duration:100000,Tags:["filling_sponge","set_block"]}
execute positioned ~ ~ ~1 if block ~ ~ ~ #fill_sponge:replace run summon marker ~ ~ ~ {Duration:100000,Tags:["filling_sponge","set_block"]}
execute positioned ~ ~ ~-1 if block ~ ~ ~ #fill_sponge:replace run summon marker ~ ~ ~ {Duration:100000,Tags:["filling_sponge","set_block"]}


scoreboard players add @e[type=marker,tag=filling_sponge,distance=..1.1] fillsponge 0
scoreboard players add @s fillsponge 1
scoreboard players operation @e[type=marker,tag=filling_sponge,distance=.1..1.1,scores={fillsponge=..0}] fillsponge = @s fillsponge

setblock ~ ~ ~ air

kill @s[tag=!start_process]

execute as @e[type=marker,tag=filling_sponge,tag=set_block] at @s run function fill_sponge:handle_setblock