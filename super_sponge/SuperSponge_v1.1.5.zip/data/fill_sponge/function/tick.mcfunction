execute as @e[type=marker,tag=filling_sponge,tag=!set_block,limit=100] if score @s fillsponge <= maximum fillsponge at @s run function fill_sponge:handle_one
# execute as @e[type=marker,tag=filled_sponge] at @s run function fill_sponge:check_remove_block
execute as @e[type=marker,tag=filling_sponge,limit=100] if score @s fillsponge > maximum fillsponge at @s run function fill_sponge:remove_end
execute unless entity @e[type=marker,tag=filling_sponge,limit=1] as @e[type=marker,tag=start_process] at @s run function fill_sponge:remove_start
