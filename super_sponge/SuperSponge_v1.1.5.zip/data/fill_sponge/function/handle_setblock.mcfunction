setblock ~ ~ ~ end_stone
tag @s remove set_block