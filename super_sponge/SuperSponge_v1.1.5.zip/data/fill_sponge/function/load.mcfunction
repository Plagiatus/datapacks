scoreboard objectives add fillsponge dummy

scoreboard players add maximum fillsponge 0
execute if score maximum fillsponge matches ..0 run scoreboard players set maximum fillsponge 10

tellraw @a ["",{"text":"","color":"green","extra":["Thank you for using ",{"text":"Plagiatus' Magic Filling Sponges","color":"dark_green"},".\nIf you have any questions or have found a bug, please contact me via ",{"text":"the contact form on plagiatus.net","italic":true,"underlined":true,"clickEvent":{"action":"open_url","value":"https://plagiatus.net#contact"},"hoverEvent":{"action":"show_text","value":{"text":"","extra":[{"text":"click here"}]}}},{"text":" or ","italic":false,"underlined":false},{"text":"on the datapacks Github page","italic":true,"underlined":true,"clickEvent":{"action":"open_url","value":"https://github.com/plagiatus/datapacks"},"hoverEvent":{"action":"show_text","value":{"text":"","extra":[{"text":"click here"}]}}}]}] 