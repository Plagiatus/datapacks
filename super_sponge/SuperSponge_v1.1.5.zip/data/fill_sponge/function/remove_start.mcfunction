kill @s
# summon item ~ ~ ~ {Item:{Count:1,id:"minecraft:end_stone",tag:{HideFlags:1,Enchantments:[{id:"minecraft:riptide",lvl:1s}],display:{Name:"{\"text\":\"Magical Filling Sponge\",\"italic\":false}"}}}}
summon item ~ ~ ~ {Item:{ \
    "id": "minecraft:end_stone", \
    "components": { \
      "minecraft:enchantments": { \
        "minecraft:riptide": 1 \
      }, \
      "minecraft:tooltip_display": { \
        "hidden_components": [ \
          "minecraft:enchantments" \
        ] \
      }, \
      "minecraft:item_name": {"text":"Magical Filling Sponge"} \
    }\
  }}